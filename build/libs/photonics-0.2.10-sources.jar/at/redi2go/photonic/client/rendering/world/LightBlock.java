package at.redi2go.photonic.client.rendering.world;

import net.minecraft.class_2248;

public class LightBlock {
   public final class_2248 block;
   public LightType lightType;

   public LightBlock(class_2248 block, LightType lightType) {
      this.block = block;
      this.lightType = lightType;
   }
}
