package at.redi2go.photonic.client.rendering;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.joml.Vector3f;

public class MinecraftAccessor {
   public static Vector3f getCameraPosition() {
      class_243 position = class_310.method_1551().field_1773.method_19418().method_19326();
      return new Vector3f((float)position.field_1352, (float)position.field_1351, (float)position.field_1350);
   }

   public static class_638 getLevel() {
      return class_310.method_1551().field_1687;
   }
}
