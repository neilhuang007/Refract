package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.BakedQuadExt;
import at.redi2go.photonic.client.BlockBuilder;
import at.redi2go.photonic.client.Raytracer;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_777;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_778.class)
public class BlockModelRendererMixin {
   @Redirect(method = "tesselateBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;useAmbientOcclusion()Z"))
   public boolean useAmbientOcclusion() {
      return Raytracer.isDisabled() ? class_310.method_1588() : false;
   }

   @Inject(method = "putQuadData", at = @At("HEAD"), cancellable = true)
   public void putQuadData(
      class_1920 blockAndTintGetter,
      class_2680 blockState,
      class_2338 blockPos,
      class_4588 vertexConsumer,
      class_4665 pose,
      class_777 bakedQuad,
      float f,
      float g,
      float h,
      float i,
      int j,
      int k,
      int l,
      int m,
      int n,
      CallbackInfo ci
   ) {
      if (BlockBuilder.IS_BUILDING_BLOCK_BUFFER) {
         if (!((BakedQuadExt)bakedQuad).photonic$shouldBeVoxelized()) {
            ci.cancel();
         }
      }
   }
}
