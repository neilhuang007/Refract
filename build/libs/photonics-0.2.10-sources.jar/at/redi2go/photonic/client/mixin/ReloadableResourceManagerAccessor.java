package at.redi2go.photonic.client.mixin;

import java.util.List;
import net.minecraft.class_3302;
import net.minecraft.class_3304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3304.class)
public interface ReloadableResourceManagerAccessor {
   @Accessor
   List<class_3302> getListeners();
}
