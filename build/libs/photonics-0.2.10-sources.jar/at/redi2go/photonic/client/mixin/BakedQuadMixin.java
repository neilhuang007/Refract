package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.BakedQuadExt;
import net.minecraft.class_777;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_777.class)
public class BakedQuadMixin implements BakedQuadExt {
   @Unique
   private boolean shouldBeVoxelized = true;

   @Override
   public boolean photonic$shouldBeVoxelized() {
      return this.shouldBeVoxelized;
   }

   @Override
   public void photonic$setShouldBeVoxelized(boolean shouldBeVoxelized) {
      this.shouldBeVoxelized = shouldBeVoxelized;
   }
}
