package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.PhotonicsStorage;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockOcclusionCache;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = BlockOcclusionCache.class, remap = false)
public class BlockOcclusionCacheMixin {
   @Shadow
   @Final
   private class_2339 cachedPositionObject;

   @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
   public void shouldDrawSide(class_2680 selfBlockState, class_1922 view, class_2338 selfPos, class_2350 facing, CallbackInfoReturnable<Boolean> cir) {
      class_2339 neighborPos = this.cachedPositionObject;
      neighborPos.method_25505(selfPos, facing);
      class_2680 neighborBlockState = view.method_8320(neighborPos);
      if (PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.value.contains(neighborBlockState.method_26204())) {
         cir.setReturnValue(true);
         cir.cancel();
      }
   }
}
