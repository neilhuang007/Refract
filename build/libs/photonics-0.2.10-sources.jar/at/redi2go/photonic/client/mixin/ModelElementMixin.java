package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.Raytracer;
import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_783;
import net.minecraft.class_785;
import net.minecraft.class_789;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_785.class)
public class ModelElementMixin {
   @Mutable
   @Final
   @Shadow
   public Map<class_2350, class_783> faces;

   @Inject(method = "<init>", at = @At("TAIL"))
   private void init(Vector3f from, Vector3f to, Map<class_2350, class_783> faces, class_789 blockElementRotation, boolean bl, CallbackInfo ci) {
      Raytracer.filterDoubleFaces(faces, new Vector3f(from.x, from.y, from.z), new Vector3f(to.x, to.y, to.z));
   }
}
