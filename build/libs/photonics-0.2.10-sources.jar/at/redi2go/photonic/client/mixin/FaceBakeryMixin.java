package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.BakedQuadExt;
import at.redi2go.photonic.client.BlockElementFaceExt;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_3665;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_789;
import net.minecraft.class_796;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_796.class)
public class FaceBakeryMixin {
   @Inject(method = "bakeQuad", at = @At("RETURN"))
   private static void bakeQuad(
      Vector3f vector3f,
      Vector3f vector3f2,
      class_783 blockElementFace,
      class_1058 textureAtlasSprite,
      class_2350 direction,
      class_3665 modelState,
      class_789 blockElementRotation,
      boolean bl,
      CallbackInfoReturnable<class_777> cir
   ) {
      class_777 bakedQuad = (class_777)cir.getReturnValue();
      boolean shouldBeVoxelized = ((BlockElementFaceExt)(Object)blockElementFace).photonic$shouldBeVoxelized();
      ((BakedQuadExt)bakedQuad).photonic$setShouldBeVoxelized(shouldBeVoxelized);
   }
}
