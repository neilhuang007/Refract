package at.redi2go.photonic.client.mixin;

import java.util.Map;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_757.class)
public interface GameRendererAccessor {
   @Accessor
   Map<String, class_5944> getShaders();
}
