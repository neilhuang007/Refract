package at.redi2go.photonic.client.mixin;

import java.io.IOException;
import java.util.Map;
import net.minecraft.class_290;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
   @Inject(method = "reloadShaders", at = @At("TAIL"))
   public void loadShaders(class_5912 resourceProvider, CallbackInfo ci) {
      try {
         Map<String, class_5944> shaders = ((GameRendererAccessor)this).getShaders();
         class_5944 schematic6 = new class_5944(resourceProvider, "schematic6", class_290.field_1590);
         shaders.put("schematic6", schematic6);
         class_5944 schematic7 = new class_5944(resourceProvider, "schematic7", class_290.field_1590);
         shaders.put("schematic7", schematic7);
      } catch (IOException var6) {
         throw new RuntimeException(var6);
      }
   }
}
