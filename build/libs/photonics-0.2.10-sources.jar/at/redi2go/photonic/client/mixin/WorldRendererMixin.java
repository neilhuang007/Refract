package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.Raytracer;
import net.minecraft.class_2561;
import net.minecraft.class_2561.class_2562;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {
   @Shadow
   @Nullable
   private class_638 world;
   @Unique
   private static boolean initialMessageSent = false;

   @Inject(
      method = "renderLevel",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/LevelRenderer;renderSectionLayer(Lnet/minecraft/client/renderer/RenderType;DDDLorg/joml/Matrix4f;Lorg/joml/Matrix4f;)V",
         ordinal = 0
      )
   )
   public void renderSectionLayer0(
      class_9779 deltaTracker,
      boolean bl,
      class_4184 camera,
      class_757 gameRenderer,
      class_765 lightTexture,
      Matrix4f matrix4f,
      Matrix4f matrix4f2,
      CallbackInfo ci
   ) {
      if (!Raytracer.isDisabled()) {
         Raytracer.INSTANCE.getMainRenderer().setup();
      }
   }

   @Inject(method = "renderLevel", at = @At("TAIL"))
   public void renderLevelTail(
      class_9779 deltaTracker,
      boolean bl,
      class_4184 camera,
      class_757 gameRenderer,
      class_765 lightTexture,
      Matrix4f matrix4f,
      Matrix4f matrix4f2,
      CallbackInfo ci
   ) {
      if (!Raytracer.isDisabled() && !initialMessageSent && this.world != null) {
         String initialMessage = "[\"\",{\"text\":\"Thank you for trying out \"},{\"text\":\"Photonics\",\"color\":\"red\"},{\"text\":\"!\\nRemember that this is a \"},{\"text\":\"Beta\",\"color\":\"dark_aqua\"},{\"text\":\" version of my raytracing mod, bugs are expected! If you experience a bug, please report them on my Github. Thank you! (I'm using my freetime to develop this mod and it took me 3 years to get to this point, so please be friendly and leave feedback)\\n\\nReminder:\\n- You can enable \"},{\"text\":\"Multi-Threading\",\"color\":\"green\"},{\"text\":\" for increased loading speeds in the mod settings, might break some things, though\\n\\nHave fun!\"}]";
         class_2561 initialMessageText = class_2562.method_10877(initialMessage, this.world.method_30349());
         if (initialMessageText != null) {
            class_310.method_1551().field_1705.method_1743().method_1812(initialMessageText);
         }

         initialMessageSent = true;
      }
   }
}
