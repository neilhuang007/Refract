package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.BlockRendererExt;
import at.redi2go.photonic.client.PhotonicsStorage;
import at.redi2go.photonic.client.Raytracer;
import at.redi2go.photonic.client.rendering.world.LightRegistry;
import at.redi2go.photonic.client.rendering.world.position.PChunkPos;
import com.llamalad7.mixinextras.sugar.Local;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildContext;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockRenderCache;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.tasks.ChunkBuilderMeshingTask;
import net.caffeinemc.mods.sodium.client.util.task.CancellationToken;
import net.minecraft.class_1087;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChunkBuilderMeshingTask.class)
public class ChunkBuilderMeshingTaskMixin {
   @Inject(
      method = "execute(Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildContext;Lnet/caffeinemc/mods/sodium/client/util/task/CancellationToken;)Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildOutput;",
      at = @At("TAIL"),
      remap = false
   )
   public void execute(
      ChunkBuildContext buildContext,
      CancellationToken cancellationToken,
      CallbackInfoReturnable<ChunkBuildOutput> cir,
      @Local(ordinal = 0) int minX,
      @Local(ordinal = 1) int minY,
      @Local(ordinal = 2) int minZ,
      @Local(ordinal = 3) int maxX,
      @Local(ordinal = 4) int maxY,
      @Local(ordinal = 5) int maxZ
   ) {
      if (!Raytracer.isDisabled()) {
         class_2338 lowerCorner = new class_2338(minX, minY, minZ);
         class_2338 upperCorner = new class_2338(maxX, maxY, maxZ);
         Raytracer.INSTANCE
            .getWorldRegistry()
            .queueBuildJob(
               () -> Raytracer.INSTANCE
                  .getWorldRegistry()
                  .loadChunk(new PChunkPos(lowerCorner.method_10263() / 16, lowerCorner.method_10264() / 16, lowerCorner.method_10260() / 16))
            );
         Raytracer.INSTANCE.getWorldRegistry().wakeUpWorldBuilder();
         LightRegistry lightRegistry = Raytracer.INSTANCE.getWorldRegistry().getLightRegistry();

         for (class_2338 blockPos : class_2338.method_10097(lowerCorner, upperCorner)) {
            lightRegistry.onBlockLoad(new Vector3f(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()));
         }
      }
   }

   @Redirect(
      method = "execute(Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildContext;Lnet/caffeinemc/mods/sodium/client/util/task/CancellationToken;)Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildOutput;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;hasBlockEntity()Z")
   )
   public boolean hasBlockEntity(class_2680 instance) {
      return !Raytracer.isDisabled() && PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.value.contains(instance.method_26204()) ? false : instance.method_31709();
   }

   @Redirect(
      method = "execute(Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildContext;Lnet/caffeinemc/mods/sodium/client/util/task/CancellationToken;)Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildOutput;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getRenderShape()Lnet/minecraft/world/level/block/RenderShape;")
   )
   public class_2464 getRenderShape(
      class_2680 instance, @Local BlockRenderCache cache, @Local(ordinal = 0) class_2339 blockPos, @Local(ordinal = 1) class_2339 modelOffset
   ) {
      if (!Raytracer.isDisabled() && PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.value.contains(instance.method_26204())) {
         class_1087 model = cache.getBlockModels().method_3335(instance);
         ((BlockRendererExt)cache.getBlockRenderer()).photonic$setRenderingVoxelBlock(true);
         cache.getBlockRenderer().renderModel(model, instance, blockPos, modelOffset);
         ((BlockRendererExt)cache.getBlockRenderer()).photonic$setRenderingVoxelBlock(false);
         return class_2464.field_11455;
      } else {
         return instance.method_26217();
      }
   }
}
