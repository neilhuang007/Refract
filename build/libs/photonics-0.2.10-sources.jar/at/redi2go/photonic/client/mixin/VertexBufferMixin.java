package at.redi2go.photonic.client.mixin;

import at.redi2go.photonic.client.BlockBuilder;
import net.minecraft.class_284;
import net.minecraft.class_291;
import net.minecraft.class_5944;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_291.class)
public class VertexBufferMixin {
   @Inject(
      method = "_drawWithShader",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/ShaderInstance;setDefaultUniforms(Lcom/mojang/blaze3d/vertex/VertexFormat$Mode;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/platform/Window;)V",
         shift = Shift.AFTER
      )
   )
   public void drawInternal(Matrix4f viewMatrix, Matrix4f projectionMatrix, class_5944 program, CallbackInfo ci) {
      class_284 renderIndex = program.method_34582("RenderIndex");
      if (renderIndex != null) {
         renderIndex.method_35649(BlockBuilder.RENDER_INDEX);
      }
   }
}
