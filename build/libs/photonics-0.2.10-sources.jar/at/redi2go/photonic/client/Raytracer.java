package at.redi2go.photonic.client;

import at.redi2go.photonic.client.rendering.opengl.objects.Destructable;
import at.redi2go.photonic.client.rendering.opengl.rendering.MainRenderer;
import at.redi2go.photonic.client.rendering.opengl.rendering.ShaderUtil;
import at.redi2go.photonic.client.rendering.patching.Patch;
import at.redi2go.photonic.client.rendering.world.LightBlock;
import at.redi2go.photonic.client.rendering.world.LightType;
import at.redi2go.photonic.client.rendering.world.WorldRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.shaderpack.include.IncludeGraph;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_783;
import org.joml.Vector2f;
import org.joml.Vector3f;

public class Raytracer implements Destructable {
   public static Raytracer INSTANCE;
   public static final Path DEV_ENV_SHADERS_PATH = Path.of("../src/main/resources/assets/photonic/shaders");
   public static Map<String, String> SHADERPACK_CHANGED_OPTIONS = null;
   public static Properties SHADERPACK_PROPERTIES = null;
   public static final List<Patch> AVAILABLE_PATCHES = new ArrayList<>();
   public static final TerrainRenderPass VOXEL = new TerrainRenderPass(class_1921.method_23581(), false, true);
   public static final Set<class_2248> DEFAULT_VOLUMETRIC_RENDERED_BLOCKS = Set.of(
      class_2246.field_9980,
      class_2246.field_10181,
      class_2246.field_9983,
      class_2246.field_37569,
      class_2246.field_10091,
      class_2246.field_10025,
      class_2246.field_10167,
      class_2246.field_10425,
      class_2246.field_10546
   );
   public static final Set<LightBlock> DEFAULT_LIGHT_BLOCKS;
   private final MainRenderer mainRenderer;
   private final RenderDispatcher renderDispatcher;
   private final WorldRegistry worldRegistry;
   private final BlockRegistry blockRegistry = new BlockRegistry();
   public Path shaderPackPath = Iris.getShaderpacksDirectory()
      .resolve((String)Iris.getIrisConfig().getShaderPackName().orElseThrow(() -> new RuntimeException("No shaderpack selected!")));
   private final Consumer<Set<class_2248>> volumetricBlocksUpdated;

   public Raytracer() {
      this.renderDispatcher = new RenderDispatcher();
      this.worldRegistry = new WorldRegistry(this.renderDispatcher);
      this.mainRenderer = new MainRenderer(this.worldRegistry);
      this.worldRegistry.startWorldBuilder();
      this.volumetricBlocksUpdated = volumetricBlocks -> class_310.method_1551().field_1769.method_3279();
      PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.addObserver(this.volumetricBlocksUpdated);
   }

   public void queueBuildJob(Runnable job) {
      this.worldRegistry.queueBuildJob(job);
   }

   public void queueUrgentBuildJob(Runnable job) {
      this.queueBuildJob(job);
      this.worldRegistry.wakeUpWorldBuilder();
   }

   public void queueOpenGLJob(Runnable job) {
      this.worldRegistry.queueGlJob(job);
   }

   public static void filterDoubleFaces(Map<class_2350, class_783> faces, Vector3f from, Vector3f to) {
      Vector3f delta = new Vector3f(from).add(-to.x, -to.y, -to.z);
      if (delta.x * delta.y * delta.z == 0.0F) {
         Vector3f normal = new Vector3f(to).add(from).mul(0.03125F).add(new Vector3f(-0.5F, -0.5F, -0.5F));
         normal.mul(1.0F / normal.length());
         class_2350 normalDirection = Arrays.stream(class_2350.values())
            .filter(
               direction -> class_243.method_24954(direction.method_10163()).method_1026(new class_243(normal.x, normal.y, normal.z))
                  > Math.cos(Math.toRadians(45.0))
            )
            .findFirst()
            .orElse(null);
         if (normalDirection != null) {
            faces.forEach((key, value) -> {
               class_2350 oppositeDirection = key.method_10153();
               if (faces.containsKey(oppositeDirection)) {
                  if (key == normalDirection) {
                     ((BlockElementFaceExt)(Object)value).photonic$setShouldBeVoxelized(false);
                  }
               }
            });
         }
      }
   }

   @Override
   public void free() {
      this.renderDispatcher.free();
      this.blockRegistry.free();
      this.worldRegistry.free();
      this.mainRenderer.free();
      PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.removeObserver(this.volumetricBlocksUpdated);
   }

   public static boolean isDisabled() {
      return INSTANCE == null;
   }

   public static boolean shouldBeEnabled() {
      if (!Iris.getIrisConfig().areShadersEnabled()) {
         return false;
      } else {
         if (SHADERPACK_PROPERTIES == null) {
            return false;
         }
         boolean shaderPackSupported = Boolean.parseBoolean(SHADERPACK_PROPERTIES.getOrDefault("photonics.enabled", false).toString());
         boolean photonicsEnabled = Boolean.parseBoolean(SHADERPACK_CHANGED_OPTIONS.getOrDefault("PHOTONICS_ENABLED", "true"));
         return !shaderPackSupported ? false : photonicsEnabled;
      }
   }

   public static void watchFolder(File folder, Runnable callback) {
      if (folder.exists()) {
         try {
            WatchService watcher = FileSystems.getDefault().newWatchService();
            WatchKey watchKey = folder.toPath().register(watcher, StandardWatchEventKinds.ENTRY_MODIFY);
            new Thread(() -> {
               while (true) {
                  if (!watchKey.pollEvents().isEmpty()) {
                     callback.run();
                  }

                  try {
                     Thread.sleep(100L);
                  } catch (InterruptedException var3x) {
                     throw new RuntimeException(var3x);
                  }
               }
            }).start();
         } catch (IOException var4) {
            throw new RuntimeException(var4);
         }
      }
   }

   public MainRenderer getMainRenderer() {
      return this.mainRenderer;
   }

   public RenderDispatcher getRenderDispatcher() {
      return this.renderDispatcher;
   }

   public WorldRegistry getWorldRegistry() {
      return this.worldRegistry;
   }

   public BlockRegistry getBlockRegistry() {
      return this.blockRegistry;
   }

   public static Patch getAppliedPatch() {
      Patch result = Iris.getIrisConfig()
         .getShaderPackName()
         .map(config -> {
            return Patch.selectBestPatch(AVAILABLE_PATCHES, config, shouldBeEnabled());
         })
         .orElse(null);
      return result;
   }

   public static void reloadPatches() {
      AVAILABLE_PATCHES.clear();
      Path fsPath = DEV_ENV_SHADERS_PATH.resolve("patches");

      try {
         try (
            Stream<Path> fsStream = Files.exists(fsPath) ? Files.list(fsPath) : Stream.of();
            Stream<Path> classStream = Files.list(
               Path.of(Objects.requireNonNull(Patch.class.getClassLoader().getResource("assets/photonic/shaders/patches/")).toURI())
            );
         ) {
            Stream.concat(fsStream, classStream).filter(x$0 -> Files.exists(x$0)).forEach(p -> {
               try {
                  AVAILABLE_PATCHES.add(Patch.of(p, true));
                  AVAILABLE_PATCHES.add(Patch.of(p, false));
               } catch (IOException var2x) {
                  throw new RuntimeException(var2x);
               }
            });
         }
      } catch (URISyntaxException | IOException var9) {
         throw new RuntimeException(var9);
      }
   }

   public static String readShaderFile(ShaderPackPath path, boolean patchFile) {
      String source = null;
      Patch patch = getAppliedPatch();
      if (patch != null && patchFile) {
         source = patch.readPatchedFile(path);
      }

      if (source == null) {
         try {
            if (!path.isPhotonicsPath()) {
               String preprocessed = readShaderAndPreprocess(path);
               return preprocessed;
            }

            String relativeToPhotonics = path.getRelativeToPhotonics();
            Path devEnvShaderPath = DEV_ENV_SHADERS_PATH.resolve(relativeToPhotonics);
            if (Files.exists(devEnvShaderPath)) {
               String preprocessed = readShaderAndPreprocess(new ShaderPackPath(devEnvShaderPath));
               return preprocessed;
            }

            URL jarShaderUrl = IncludeGraph.class.getClassLoader().getResource("assets/photonic/shaders/" + relativeToPhotonics);
            if (jarShaderUrl == null) {
               return null;
            }

            Path jarShaderPath = Path.of(jarShaderUrl.toURI());
            if (Files.exists(jarShaderPath)) {
               String preprocessed = readShaderAndPreprocess(new ShaderPackPath(jarShaderPath));
               return preprocessed;
            }
         } catch (Exception var7) {
         }
      }

      if (source == null) {
         throw new IllegalStateException("Couldn't read file " + path);
      } else {
         return ShaderUtil.preprocessForward(source);
      }
   }

   private static String readShaderAndPreprocess(ShaderPackPath path) throws IOException {
      return ShaderUtil.preprocessForward(path.readFile());
   }

   private static void registerDefaultLightBlock(List<LightBlock> lightBlocks, Vector3f color, boolean traced, class_2248... blocks) {
      for (class_2248 block : blocks) {
         LightType lightType = new LightType(color, new Vector2f(0.9F, 0.9F), traced);
         lightBlocks.add(new LightBlock(block, lightType));
      }
   }

   public static boolean blockStateEmitsLight(class_2680 blockState) {
      class_2248 block = blockState.method_26204();
      if (block == class_2246.field_10091) {
         return (Integer)blockState.method_11654(class_2457.field_11432) > 0;
      } else {
         return block != class_2246.field_10002 && block != class_2246.field_10234 && block != class_2246.field_10441 ? blockState.method_26213() > 0 : true;
      }
   }

   static {
      watchFolder(DEV_ENV_SHADERS_PATH.toFile(), () -> RenderSystem.recordRenderCall(() -> {
         try {
            Iris.reload();
         } catch (IOException var1x) {
         }
      }));
      List<LightBlock> lightBlocks = new LinkedList<>();
      Vector3f redstoneColor = new Vector3f(255.0F, 51.0F, 51.0F).mul(0.003921569F);
      registerDefaultLightBlock(lightBlocks, redstoneColor, true, class_2246.field_10523, class_2246.field_10301);
      registerDefaultLightBlock(
         lightBlocks, redstoneColor, false, class_2246.field_10002, class_2246.field_10080, class_2246.field_29030, class_2246.field_10091
      );
      Vector3f torchColor = new Vector3f(119.0F, 106.0F, 56.0F).mul(0.003921569F);
      registerDefaultLightBlock(
         lightBlocks,
         torchColor,
         true,
         class_2246.field_27099,
         class_2246.field_27100,
         class_2246.field_27101,
         class_2246.field_27102,
         class_2246.field_27103,
         class_2246.field_27104,
         class_2246.field_27105,
         class_2246.field_27106,
         class_2246.field_27107,
         class_2246.field_27108,
         class_2246.field_27109,
         class_2246.field_27110,
         class_2246.field_27111,
         class_2246.field_27112,
         class_2246.field_27113,
         class_2246.field_27140,
         class_2246.field_27141,
         class_2246.field_27142,
         class_2246.field_27143,
         class_2246.field_27144,
         class_2246.field_27145,
         class_2246.field_27146,
         class_2246.field_27147,
         class_2246.field_27148,
         class_2246.field_27149,
         class_2246.field_27150,
         class_2246.field_27151,
         class_2246.field_27152,
         class_2246.field_27153,
         class_2246.field_27154,
         class_2246.field_27155,
         class_2246.field_27156,
         class_2246.field_27157,
         class_2246.field_27158
      );
      registerDefaultLightBlock(
         lightBlocks,
         torchColor,
         true,
         class_2246.field_10336,
         class_2246.field_10099,
         class_2246.field_10009,
         class_2246.field_16541,
         class_2246.field_17350,
         class_2246.field_10524
      );
      registerDefaultLightBlock(
         lightBlocks,
         torchColor,
         true,
         class_2246.field_47072,
         class_2246.field_47073,
         class_2246.field_47075,
         class_2246.field_47074,
         class_2246.field_47076,
         class_2246.field_47077,
         class_2246.field_47079,
         class_2246.field_47078
      );
      registerDefaultLightBlock(
         lightBlocks,
         torchColor,
         false,
         class_2246.field_10164,
         class_2246.field_10092,
         class_2246.field_22122,
         class_2246.field_10171,
         class_2246.field_27098,
         class_2246.field_10036,
         class_2246.field_10333,
         class_2246.field_10181,
         class_2246.field_16333,
         class_2246.field_16334,
         class_2246.field_28675,
         class_2246.field_28676
      );
      Vector3f soulColor = new Vector3f(51.0F, 204.0F, 255.0F).mul(0.003921569F);
      registerDefaultLightBlock(lightBlocks, soulColor, true, class_2246.field_22092, class_2246.field_22093, class_2246.field_22110, class_2246.field_23860);
      registerDefaultLightBlock(lightBlocks, soulColor, false, class_2246.field_22089);
      Vector3f endColor = new Vector3f(170.0F, 170.0F, 170.0F).mul(0.003921569F);
      registerDefaultLightBlock(lightBlocks, endColor, true, class_2246.field_10455);
      registerDefaultLightBlock(lightBlocks, endColor, false, class_2246.field_10027, class_2246.field_10398, class_2246.field_10613);
      Vector3f whiteColor = new Vector3f(100.0F, 100.0F, 100.0F).mul(0.003921569F);
      registerDefaultLightBlock(
         lightBlocks, whiteColor, false, class_2246.field_31037, class_2246.field_10443, class_2246.field_10476, class_2246.field_10174, class_2246.field_10327
      );
      registerDefaultLightBlock(lightBlocks, new Vector3f(whiteColor).mul(0.5F), true, class_2246.field_10081);
      registerDefaultLightBlock(lightBlocks, new Vector3f(whiteColor).mul(0.5F), false, class_2246.field_47336);
      registerDefaultLightBlock(lightBlocks, new Vector3f(whiteColor).mul(0.5F), false, class_2246.field_48851);
      Vector3f purpleColor = new Vector3f(131.0F, 8.0F, 228.0F).mul(0.003921569F);
      registerDefaultLightBlock(lightBlocks, purpleColor, false, class_2246.field_22423, class_2246.field_23152, class_2246.field_10316);
      Vector3f amethystColor = new Vector3f(new Vector3f(122.0F, 91.0F, 181.0F).mul(0.003921569F));
      registerDefaultLightBlock(
         lightBlocks,
         amethystColor,
         false,
         class_2246.field_27159,
         class_2246.field_27161,
         class_2246.field_27162,
         class_2246.field_27163,
         class_2246.field_27164
      );
      Vector3f sculkColor = new Vector3f(39.0F, 133.0F, 145.0F).mul(0.003921569F);
      registerDefaultLightBlock(lightBlocks, sculkColor, false, class_2246.field_28108, class_2246.field_43231, class_2246.field_37570);
      registerDefaultLightBlock(lightBlocks, new Vector3f(0.0F, 0.0F, 0.0F).mul(0.003921569F), false, class_2246.field_10251, class_2246.field_10502);
      registerDefaultLightBlock(lightBlocks, new Vector3f(227.0F, 236.0F, 228.0F).mul(0.003921569F), false, class_2246.field_37571);
      registerDefaultLightBlock(lightBlocks, new Vector3f(29.0F, 74.0F, 149.0F).mul(0.003921569F), false, class_2246.field_10441);
      registerDefaultLightBlock(lightBlocks, new Vector3f(23.0F, 221.0F, 98.0F).mul(0.003921569F), false, class_2246.field_10234);
      registerDefaultLightBlock(lightBlocks, new Vector3f(178.0F, 138.0F, 189.0F).mul(0.003921569F), false, class_2246.field_37574);
      registerDefaultLightBlock(lightBlocks, new Vector3f(145.0F, 195.0F, 130.0F).mul(0.003921569F), false, class_2246.field_37573);
      registerDefaultLightBlock(lightBlocks, new Vector3f(150.0F, 220.0F, 134.0F).mul(0.003921569F), false, class_2246.field_37572);
      registerDefaultLightBlock(lightBlocks, new Vector3f(128.0F, 70.0F, 0.0F).mul(0.003921569F), false, class_2246.field_10485);
      registerDefaultLightBlock(lightBlocks, new Vector3f(113.0F, 134.0F, 126.0F).mul(0.003921569F), false, class_2246.field_28411);
      DEFAULT_LIGHT_BLOCKS = new HashSet<>(lightBlocks);
   }
}
