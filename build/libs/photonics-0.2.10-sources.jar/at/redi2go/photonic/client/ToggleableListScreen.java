package at.redi2go.photonic.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_7842;
import net.minecraft.class_7847;
import net.minecraft.class_8132;
import net.minecraft.class_8667;
import org.jetbrains.annotations.NotNull;

public class ToggleableListScreen extends class_437 {
   private final class_437 parent;
   private final ToggleableListScreen.Model model;
   private final class_8132 layout = new class_8132(this, 61, 33);
   private ToggleableListScreen.ToggleableList list;

   public ToggleableListScreen(class_437 parent, String headline, ToggleableListScreen.Model model) {
      super(class_2561.method_30163(headline));
      this.parent = parent;
      this.model = model;
   }

   protected void method_25426() {
      super.method_25426();
      class_342 searchBox = new class_342(this.field_22793, 200, 20, class_2561.method_30163("Search"));
      searchBox.method_1863(searchText -> {
         this.model.setFilter(searchText);
         this.list.init();
      });
      class_8667 searchLinearLayout = (class_8667)this.layout.method_48992(class_8667.method_52741().method_52735(8));
      searchLinearLayout.method_52738(new class_7842(this.method_25440(), this.field_22793), class_7847::method_46467);
      searchLinearLayout.method_52738(searchBox, class_7847::method_46467);
      this.list = new ToggleableListScreen.ToggleableList(class_310.method_1551(), this);
      this.list.init();
      this.layout.method_48999(this.list);
      this.layout.method_48996(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419()).method_46432(200).method_46431());
      this.layout.method_48206(x$0 -> {
         class_339 var10000 = (class_339)this.method_37063(x$0);
      });
      this.layout.method_48222();
   }

   protected void method_48640() {
      this.layout.method_48222();
      this.list.method_57712(this.field_22789, this.layout);
   }

   public void method_25394(@NotNull class_332 drawContext, int mouseX, int mouseY, float delta) {
      super.method_25420(drawContext, mouseX, mouseY, delta);
      super.method_25394(drawContext, mouseX, mouseY, delta);
   }

   public void method_25419() {
      if (this.field_22787 != null) {
         this.field_22787.method_1507(this.parent);
      }
   }

   public abstract static class Entry extends class_4265.class_4266<ToggleableListScreen.Entry> {
      abstract void refreshEntry();
   }

   public static class Model {
      private final List<ToggleableListScreen.ModelEntry> content;
      private final List<ToggleableListScreen.ModelEntry> filteredContent = new ArrayList<>();

      public Model(List<ToggleableListScreen.ModelEntry> content) {
         this.content = content;
         this.setFilter("");
      }

      public void setFilter(String filter) {
         List<String> filterTokens = Arrays.stream(filter.split(" ")).map(String::toLowerCase).toList();
         this.filteredContent.clear();
         this.content.stream().filter(entry -> {
            String displayValue = entry.getDisplayValue().toLowerCase();

            for (String filterToken : filterTokens) {
               if (!displayValue.contains(filterToken)) {
                  return false;
               }
            }

            return true;
         }).forEach(this.filteredContent::add);
      }

      public List<ToggleableListScreen.ModelEntry> getFilteredContent() {
         return this.filteredContent;
      }
   }

   public abstract static class ModelEntry {
      public abstract String getDisplayValue();

      public abstract boolean isEnabled();

      public abstract void setEnabled(boolean var1);
   }

   public class ToggleableList extends class_4265<ToggleableListScreen.Entry> {
      public ToggleableList(class_310 minecraft, ToggleableListScreen toggleableListScreen) {
         super(minecraft, toggleableListScreen.field_22789, toggleableListScreen.layout.method_57727(), toggleableListScreen.layout.method_48998(), 20);
      }

      public void init() {
         this.method_25339();

         for (ToggleableListScreen.ModelEntry entry : ToggleableListScreen.this.model.getFilteredContent()) {
            this.method_25321(new ToggleableListScreen.ToggleableList.ListEntry(entry));
         }
      }

      public class ListEntry extends ToggleableListScreen.Entry {
         private final ToggleableListScreen.ModelEntry model;
         private final class_4185 toggleButton;

         public ListEntry(ToggleableListScreen.ModelEntry model) {
            this.model = model;
            this.toggleButton = class_4185.method_46430(class_2561.method_30163(model.isEnabled() ? "ON" : "OFF"), button -> {
               model.setEnabled(!model.isEnabled());
               this.refreshEntry();
            }).method_46434(0, 0, 75, 20).method_46431();
         }

         @Override
         void refreshEntry() {
            this.toggleButton.method_25355(class_2561.method_30163(this.model.isEnabled() ? "ON" : "OFF"));
         }

         @NotNull
         public List<? extends class_6379> method_37025() {
            return List.of();
         }

         public void method_25343(@NotNull class_332 guiGraphics, int i, int j, int k, int l, int m, int n, int o, boolean bl, float f) {
            int p = ToggleableList.this.method_25329() - 10;
            int q = j - 2;
            int r = p - 5 - this.toggleButton.method_25368();
            this.toggleButton.method_48229(r, q);
            this.toggleButton.method_25394(guiGraphics, n, o, f);
            class_327 var10001 = ToggleableList.this.field_22740.field_1772;
            class_2561 var10002 = class_2561.method_30163(this.model.getDisplayValue());
            int var10004 = j + m / 2;
            Objects.requireNonNull(ToggleableList.this.field_22740.field_1772);
            guiGraphics.method_27535(var10001, var10002, k, var10004 - 4, -1);
         }

         @NotNull
         public List<? extends class_364> method_25396() {
            return List.of(this.toggleButton);
         }
      }
   }
}
