package at.redi2go.photonic.client;

import at.redi2go.photonic.client.rendering.world.LightBlock;
import at.redi2go.photonic.client.rendering.world.LightType;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_357;
import net.minecraft.class_3902;
import net.minecraft.class_4011;
import net.minecraft.class_4185;
import net.minecraft.class_4185.class_4241;
import net.minecraft.class_425;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7842;
import net.minecraft.class_7845;
import net.minecraft.class_7845.class_7939;
import net.minecraft.class_7847;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import net.minecraft.class_8132;
import net.minecraft.class_8667;
import org.jetbrains.annotations.NotNull;

public class ModSettingsScreen extends class_437 {
   private static final ToggleableListScreen.Model BLOCKS_3D_MODEL = new ToggleableListScreen.Model(class_7923.field_41175.method_10220().filter(block -> {
      Set<class_2248> blacklistedBlocks = Set.of(class_2246.field_10124, class_2246.field_10382, class_2246.field_10164);
      return !blacklistedBlocks.contains(block);
   }).sorted(Comparator.comparing(block -> block.method_9518().getString())).map(block -> (ToggleableListScreen.ModelEntry)new ModSettingsScreen.BlockModel3DEntry(block)).toList());
   private static final ToggleableListScreen.Model BLOCKS_TRACED_MODEL;
   private final class_437 parent;
   private SchematicExporter schematicExporter = null;
   private final class_8132 layout = new class_8132(this, 61, 33);

   protected ModSettingsScreen(class_437 parent) {
      super(class_2561.method_30163("Photonic Client Settings"));
      this.parent = parent;
   }

   protected void method_25426() {
      super.method_25426();
      List<ModSettingsScreen.PButton> buttons = new ArrayList<>();
      buttons.add(
         new ModSettingsScreen.PButton(
            "Generate schematics.zip",
            w -> this.exportSchematics(),
            "Exports all blockstates to the root\nMinecraft folder (schematics.zip). Only works in-game!",
            () -> class_310.method_1551().field_1687 != null
         )
      );
      PhotonicsStorage.Parameter<Boolean> doMultithreading = PhotonicsStorage.DO_MULTITHREADING;
      buttons.add(new ModSettingsScreen.PButton("MultiThreading: " + (doMultithreading.value ? "On" : "Off"), w -> {
         doMultithreading.value = !doMultithreading.value;
         doMultithreading.modified();
         w.method_25355(class_2561.method_30163("MultiThreading: " + (doMultithreading.value ? "On" : "Off")));
      }, "Turns MultiThreading on or off; MultiThreading is considerably faster, but can cause bugs.", () -> true));
      PhotonicsStorage.Parameter<Boolean> pixelatedProjection = PhotonicsStorage.PIXELATED_PROJECTION;
      PhotonicsStorage.Parameter<Float> castLightPixelSize = PhotonicsStorage.CAST_LIGHT_PIXEL_SIZE;
      ModSettingsScreen.CastLightPixelSizeSlider castLightPixelSizeSlider = new ModSettingsScreen.CastLightPixelSizeSlider(castLightPixelSize);
      castLightPixelSizeSlider.field_22763 = pixelatedProjection.value;
      buttons.add(new ModSettingsScreen.PButton("Pixelated Projection: " + (pixelatedProjection.value ? "On" : "Off"), w -> {
         pixelatedProjection.value = !pixelatedProjection.value;
         pixelatedProjection.modified();
         castLightPixelSizeSlider.field_22763 = pixelatedProjection.value;
         w.method_25355(class_2561.method_30163("Pixelated Projection: " + (pixelatedProjection.value ? "On" : "Off")));
      }, "Turns pixelated projected RT cast light on or off.", () -> true));
      ModSettingsScreen.OilifySizeSlider oilifySizeSlider = new ModSettingsScreen.OilifySizeSlider(PhotonicsStorage.OILIFY_SIZE);
      oilifySizeSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifySharpnessSlider oilifySharpnessSlider = new ModSettingsScreen.OilifySharpnessSlider(PhotonicsStorage.OILIFY_SHARPNESS);
      oilifySharpnessSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyScaleSlider oilifyScaleSlider = new ModSettingsScreen.OilifyScaleSlider(PhotonicsStorage.OILIFY_SCALE);
      oilifyScaleSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyTuningSlider oilifyTuningSlider = new ModSettingsScreen.OilifyTuningSlider(PhotonicsStorage.OILIFY_TUNING);
      oilifyTuningSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyIterationsSlider oilifyIterationsSlider = new ModSettingsScreen.OilifyIterationsSlider(PhotonicsStorage.OILIFY_ITERATIONS);
      oilifyIterationsSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyDepthScalingSlider oilifyDepthScalingSlider = new ModSettingsScreen.OilifyDepthScalingSlider(PhotonicsStorage.OILIFY_DEPTH_SCALING);
      oilifyDepthScalingSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyStrokeStrengthSlider oilifyStrokeStrengthSlider = new ModSettingsScreen.OilifyStrokeStrengthSlider(PhotonicsStorage.OILIFY_STROKE_STRENGTH);
      oilifyStrokeStrengthSlider.field_22763 = PhotonicsStorage.OILIFY_ENABLED.value;
      PhotonicsStorage.Parameter<Boolean> oilify = PhotonicsStorage.OILIFY_ENABLED;
      buttons.add(new ModSettingsScreen.PButton("Oilify: " + (oilify.value ? "On" : "Off"), w -> {
         oilify.value = !oilify.value;
         oilify.modified();
         oilifySizeSlider.field_22763 = oilify.value;
         oilifySharpnessSlider.field_22763 = oilify.value;
         oilifyScaleSlider.field_22763 = oilify.value;
         oilifyTuningSlider.field_22763 = oilify.value;
         oilifyIterationsSlider.field_22763 = oilify.value;
         oilifyDepthScalingSlider.field_22763 = oilify.value;
         oilifyStrokeStrengthSlider.field_22763 = oilify.value;
         w.method_25355(class_2561.method_30163("Oilify: " + (oilify.value ? "On" : "Off")));
      }, "Applies an oil painting effect to the world using\nan anisotropic Kuwahara filter.", () -> true));
      ToggleableListScreen volumetricRenderedBlocks = new ToggleableListScreen(this, "3D Blocks", BLOCKS_3D_MODEL);
      buttons.add(
         new ModSettingsScreen.PButton(
            "3D Blocks",
            w -> this.field_22787.method_1507(volumetricRenderedBlocks),
            "Configures, whether a specific block should be rendered as a 3D block",
            () -> true
         )
      );
      ToggleableListScreen tracedBlocks = new ToggleableListScreen(this, "Raytraced Block Lights", BLOCKS_TRACED_MODEL);
      buttons.add(
         new ModSettingsScreen.PButton(
            "Raytraced Lights",
            w -> this.field_22787.method_1507(tracedBlocks),
            "Configures, whether a specific block should emit ray-traced light",
            () -> true
         )
      );
      class_8667 linearLayout = (class_8667)this.layout.method_48992(class_8667.method_52741().method_52735(8));
      linearLayout.method_52738(new class_7842(class_2561.method_30163("Photonics Mod settings"), this.field_22793), class_7847::method_46467);
      class_7845 gridLayout = new class_7845();
      gridLayout.method_46458().method_46477(4).method_46475(4).method_46467();
      class_7939 rowHelper = gridLayout.method_47610(2);
      int midX = this.field_22789 / 2;
      int i = 0;

      for (ModSettingsScreen.PButton button : buttons) {
         int x = i % 2 * 220 + midX - 210;
         int y = (i / 2 + 1) * 30;
         button.widget = class_4185.method_46430(class_2561.method_30163(button.text), button.pressAction)
            .method_46433(x, y)
            .method_46437(200, 20)
            .method_46436(class_7919.method_47407(class_2561.method_30163(button.toolTip)))
            .method_46431();
         button.widget.field_22763 = button.active.getAsBoolean();
         rowHelper.method_47612(button.widget);
         i++;
      }

      rowHelper.method_47613(castLightPixelSizeSlider, 2);
      rowHelper.method_47613(oilifySizeSlider, 2);
      rowHelper.method_47613(oilifySharpnessSlider, 2);
      rowHelper.method_47613(oilifyScaleSlider, 2);
      rowHelper.method_47613(oilifyTuningSlider, 2);
      rowHelper.method_47613(oilifyIterationsSlider, 2);
      rowHelper.method_47613(oilifyDepthScalingSlider, 2);
      rowHelper.method_47613(oilifyStrokeStrengthSlider, 2);

      this.layout.method_48999(gridLayout);
      this.layout.method_48996(class_4185.method_46430(class_5244.field_24334, buttonx -> this.method_25419()).method_46432(200).method_46431());
      this.layout.method_48206(x$0 -> {
         class_339 var10000 = (class_339)this.method_37063(x$0);
      });
      this.layout.method_48222();
   }

   public void method_25394(@NotNull class_332 drawContext, int mouseX, int mouseY, float delta) {
      super.method_25420(drawContext, mouseX, mouseY, delta);
      super.method_25394(drawContext, mouseX, mouseY, delta);
   }

   public void exportSchematics() {
      if (this.schematicExporter == null) {
         try {
            this.schematicExporter = new SchematicExporter(new File("."));
            class_310.method_1551().method_18502(buildLoadingOverlay(() -> {
               if (this.schematicExporter == null) {
                  return 1.0F;
               } else {
                  for (int i = 0; i < 100; i++) {
                     if (!this.schematicExporter.exportOne()) {
                        this.schematicExporter = null;
                        return 1.0F;
                     }
                  }

                  return this.schematicExporter.getProgress();
               }
            }));
         } catch (FileNotFoundException var2) {
            var2.printStackTrace();
         }
      }
   }

   public void method_25419() {
      this.field_22787.method_1507(this.parent);
   }

   private static class_425 buildLoadingOverlay(Supplier<Float> progressSupplier) {
      return new class_425(class_310.method_1551(), new class_4011() {
         public CompletableFuture<class_3902> method_18364() {
            return null;
         }

         public float method_18229() {
            return progressSupplier.get();
         }

         public boolean method_18787() {
            return this.method_18229() == 1.0F;
         }
      }, o -> {}, false);
   }

   static {
      Set<LightBlock> lightBlocks = PhotonicsStorage.TRACED_LIGHT_BLOCKS.value;
      BLOCKS_TRACED_MODEL = new ToggleableListScreen.Model(
         lightBlocks.stream()
            .sorted(Comparator.comparing(lightblock -> lightblock.block.method_9518().getString()))
            .map(lightBlock -> (ToggleableListScreen.ModelEntry)new ModSettingsScreen.TracedLightBlockEntry(lightBlock.block))
            .toList()
      );
   }

   public static class BlockModel3DEntry extends ToggleableListScreen.ModelEntry {
      private final class_2248 block;

      public BlockModel3DEntry(class_2248 block) {
         this.block = block;
      }

      @Override
      public String getDisplayValue() {
         return this.block.method_9518().getString();
      }

      @Override
      public boolean isEnabled() {
         return PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.value.contains(this.block);
      }

      @Override
      public void setEnabled(boolean enabled) {
         PhotonicsStorage.Parameter<Set<class_2248>> lightBlocks = PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS;
         if (enabled) {
            lightBlocks.value.add(this.block);
         } else {
            lightBlocks.value.remove(this.block);
         }

         lightBlocks.modified();
      }
   }

   private static class PButton {
      public class_4185 widget;
      public final String text;
      public final class_4241 pressAction;
      public final String toolTip;
      public final BooleanSupplier active;

      public PButton(String text, class_4241 pressAction, String toolTip, BooleanSupplier active) {
         this.text = text;
         this.pressAction = pressAction;
         this.toolTip = toolTip;
         this.active = active;
      }
   }

   private static class CastLightPixelSizeSlider extends class_357 {
      private static final int MIN_PIXEL_SIZE = 1;
      private static final int MAX_PIXEL_SIZE = 24;
      private final PhotonicsStorage.Parameter<Float> castLightPixelSize;

      CastLightPixelSizeSlider(PhotonicsStorage.Parameter<Float> castLightPixelSize) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(castLightPixelSize.value));
         this.castLightPixelSize = castLightPixelSize;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Cast Light Pixel Size: " + this.getPixelSize()));
      }

      @Override
      protected void method_25344() {
         this.castLightPixelSize.value = this.getPixelSize();
         this.castLightPixelSize.modified();
         this.method_25346();
      }

      private static double normalize(float pixelSize) {
         float clamped = Math.max(MIN_PIXEL_SIZE, Math.min(MAX_PIXEL_SIZE, pixelSize));
         return (clamped - MIN_PIXEL_SIZE) / (MAX_PIXEL_SIZE - MIN_PIXEL_SIZE);
      }

      private float getPixelSize() {
         float pixelSize = MIN_PIXEL_SIZE + (float)Math.round(this.field_22753 * (MAX_PIXEL_SIZE - MIN_PIXEL_SIZE));
         return Math.max(MIN_PIXEL_SIZE, Math.min(MAX_PIXEL_SIZE, pixelSize));
      }
   }

   private static class OilifySizeSlider extends class_357 {
      private static final float MIN = 3.0f;
      private static final float MAX = 15.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifySizeSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(param.value));
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("OILIFY_SIZE: " + (int) getValue()));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         return Math.max(MIN, Math.min(MAX, MIN + Math.round((float)(this.field_22753 * (MAX - MIN)))));
      }
   }

   private static class OilifySharpnessSlider extends class_357 {
      private static final float MIN = 0.0f;
      private static final float MAX = 1.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifySharpnessSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), param.value);
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Sharpness: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private float getValue() {
         return (float) Math.max(MIN, Math.min(MAX, this.field_22753));
      }
   }

   private static class OilifyScaleSlider extends class_357 {
      private static final float MIN = 1.0f;
      private static final float MAX = 4.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyScaleSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(param.value));
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Scale: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.field_22753 * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyTuningSlider extends class_357 {
      private static final float MIN = 0.0f;
      private static final float MAX = 4.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyTuningSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(param.value));
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Anistropy Tuning: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.field_22753 * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyIterationsSlider extends class_357 {
      private static final float MIN = 1.0f;
      private static final float MAX = 8.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyIterationsSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(param.value));
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("OILIFY_ITERATIONS: " + (int)getValue()));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         return Math.max(MIN, Math.min(MAX, MIN + Math.round((float)(this.field_22753 * (MAX - MIN)))));
      }
   }

   private static class OilifyDepthScalingSlider extends class_357 {
      private static final float MIN = 0.0f;
      private static final float MAX = 2.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyDepthScalingSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), normalize(param.value));
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Depth Scaling: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.field_22753 * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyStrokeStrengthSlider extends class_357 {
      private static final float MIN = 0.0f;
      private static final float MAX = 1.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyStrokeStrengthSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, class_2561.method_30163(""), param.value);
         this.param = param;
         this.method_25346();
      }

      @Override
      protected void method_25346() {
         this.method_25355(class_2561.method_30163("Stroke Strength: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void method_25344() {
         this.param.value = getValue();
         this.param.modified();
         this.method_25346();
      }

      private float getValue() {
         return (float) Math.max(MIN, Math.min(MAX, this.field_22753));
      }
   }

   public static class TracedLightBlockEntry extends ToggleableListScreen.ModelEntry {
      private final class_2248 block;

      public TracedLightBlockEntry(class_2248 block) {
         this.block = block;
      }

      @Override
      public String getDisplayValue() {
         return class_7923.field_41175.method_10221(this.block).method_12832();
      }

      @Override
      public boolean isEnabled() {
         return PhotonicsStorage.TRACED_LIGHT_BLOCKS.value.stream().anyMatch(lightBlock -> lightBlock.block == this.block && lightBlock.lightType.isTraced());
      }

      @Override
      public void setEnabled(boolean traced) {
         PhotonicsStorage.Parameter<Set<LightBlock>> lightBlocks = PhotonicsStorage.TRACED_LIGHT_BLOCKS;
         LightBlock lightBlock = lightBlocks.value.stream().filter(lightBlock1 -> lightBlock1.block == this.block).findFirst().orElse(null);
         if (lightBlock != null) {
            lightBlock.lightType = new LightType(lightBlock.lightType.getColor(), lightBlock.lightType.getAttenuation(), traced);
            lightBlocks.modified();
         }
      }
   }
}
