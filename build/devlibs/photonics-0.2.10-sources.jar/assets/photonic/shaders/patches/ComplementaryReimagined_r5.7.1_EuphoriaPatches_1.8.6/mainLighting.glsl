#file "/lib/lighting/mainLighting.glsl"

#replace "vec3 blockLighting = lightmapXM * blocklightCol;"
vec3 blockLighting = lightmapXM * blocklightCol;
#ifdef PHOTONICS_ENABLED
    // Native block lighting must be disabled when RT block lighting is composited in deferred.
    blockLighting = vec3(0.0);
#endif
#endreplace

#replace "vec3 sceneLighting = lightColorM * shadowLightMult + ambientColorM * ambientMult;"
vec3 sceneLighting = lightColorM * shadowLightMult + ambientColorM * ambientMult;
#ifdef PHOTONICS_ENABLED
    // Keep direct shadowed sunlight mostly intact and attenuate ambient to avoid additive over-lighting.
    sceneLighting = lightColorM * shadowLightMult + ambientColorM * ambientMult * 0.6;
#endif
#endreplace

#replace "vec3 heldLighting = GetHeldLighting(playerPosForHeldLighting, color.rgb, emission, worldGeoNormal, normalM, viewPos);"
#ifdef PHOTONICS_ENABLED
        vec3 heldLighting = vec3(0.0);
#else
        vec3 heldLighting = GetHeldLighting(playerPosForHeldLighting, color.rgb, emission, worldGeoNormal, normalM, viewPos);
#endif
#endreplace
