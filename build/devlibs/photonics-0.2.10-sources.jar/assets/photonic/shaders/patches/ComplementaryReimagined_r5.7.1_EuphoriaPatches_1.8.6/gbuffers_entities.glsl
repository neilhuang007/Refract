#file "/program/gbuffers_entities.glsl"

#replace "vec3 normalM = normal, shadowMult = vec3(1.0);"
vec3 normalM = normal, shadowMult = vec3(1.0);
vec3 oldAlbedo = vec3(0.0);
#endreplace

#replace "DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, 0.5,"
oldAlbedo = color.rgb;
DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, 0.5,
#endreplace

#replace "/* DRAWBUFFERS:036 */"
/* RENDERTARGETS:0,3,6,10,11 */
#endreplace

#replace "gl_FragData[2] = vec4(smoothnessD, materialMask, skyLightFactor, lmCoord.x + clamp01(purkinjeOverwrite) + clamp01(emissionOld));"
gl_FragData[2] = vec4(smoothnessD, materialMask, skyLightFactor, lmCoord.x + clamp01(purkinjeOverwrite) + clamp01(emissionOld));
gl_FragData[3] = vec4(oldAlbedo, 1.0);
gl_FragData[4] = vec4(0.5 * normalM + 0.5, 1.0);
#endreplace

#replace "/* DRAWBUFFERS:0364 */"
/* RENDERTARGETS:0,3,6,4,10,11 */
#endreplace

#replace "gl_FragData[3] = vec4(mat3(gbufferModelViewInverse) * normalM, 1.0);"
gl_FragData[3] = vec4(mat3(gbufferModelViewInverse) * normalM, 1.0);
gl_FragData[4] = vec4(oldAlbedo, 1.0);
gl_FragData[5] = vec4(0.5 * normalM + 0.5, 1.0);
#endreplace

#replace "/* DRAWBUFFERS:03649 */"
/* RENDERTARGETS:0,3,6,4,9,10,11 */
#endreplace

#replace "gl_FragData[4] = vec4(lightAlbedo, entitySSBLMask);"
gl_FragData[4] = vec4(lightAlbedo, entitySSBLMask);
gl_FragData[5] = vec4(oldAlbedo, 1.0);
gl_FragData[6] = vec4(0.5 * normalM + 0.5, 1.0);
#endreplace

#replace "/* DRAWBUFFERS:0369 */"
/* RENDERTARGETS:0,3,6,9,10,11 */
#endreplace

#replace "gl_FragData[3] = vec4(lightAlbedo, entitySSBLMask);"
gl_FragData[3] = vec4(lightAlbedo, entitySSBLMask);
gl_FragData[4] = vec4(oldAlbedo, 1.0);
gl_FragData[5] = vec4(0.5 * normalM + 0.5, 1.0);
#endreplace
