#file "/program/deferred1.glsl"

#replace "const bool colortex0MipmapEnabled = true;"
const bool colortex0MipmapEnabled = true;

uniform sampler2D radiosity_handheld;
uniform sampler2D radiosity_direct;
uniform sampler2D radiosity_direct_soft;
uniform sampler2D colortex10;
uniform sampler2D colortex12;
uniform float ph_debug_lighting_master_scale;
#endreplace

#replace "vec4 color = vec4(albedoTextureSample.rgb, 1.0);"
vec4 color = vec4(albedoTextureSample.rgb, 1.0);
float photonicsDepth = texelFetch(depthtex0, texelCoord, 0).r;
if (photonicsDepth < 0.99999 && photonicsDepth >= 0.56) {
	vec3 photonicsAlbedo = texelFetch(colortex10, texelCoord, 0).rgb;
	if (any(isnan(photonicsAlbedo)) || any(isinf(photonicsAlbedo))) {
		photonicsAlbedo = vec3(0.0);
	}
	photonicsAlbedo = clamp(photonicsAlbedo, vec3(0.0), vec3(1.0));
	if (photonicsAlbedo.r > 0.0 || photonicsAlbedo.g > 0.0 || photonicsAlbedo.b > 0.0) {
		vec4 directSoft = texelFetch(radiosity_direct_soft, texelCoord, 0);
		vec3 direct = texelFetch(radiosity_handheld, texelCoord, 0).rgb
			+ texelFetch(radiosity_direct, texelCoord, 0).rgb
			+ directSoft.rgb / max(directSoft.a, 1.0);
		vec3 indirect = texelFetch(colortex12, texelCoord, 0).rgb * 0.15;
		vec3 photonicsLighting = max(indirect + direct, vec3(0.0));
		if (any(isnan(photonicsLighting)) || any(isinf(photonicsLighting))) {
			photonicsLighting = vec3(0.0);
		}
		photonicsLighting = min(photonicsLighting, vec3(5.0));
		photonicsLighting *= clamp(ph_debug_lighting_master_scale, 0.0, 4.0);
		color.rgb += photonicsLighting * photonicsAlbedo;
	}
}
#endreplace
