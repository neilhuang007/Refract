package at.redi2go.photonic.client;

import at.redi2go.photonic.client.rendering.world.LightBlock;
import at.redi2go.photonic.client.rendering.world.LightType;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.util.Unit;
import net.minecraft.resource.ResourceReload;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.client.gui.widget.GridWidget;
import net.minecraft.client.gui.widget.Positioner;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.registry.Registries;
import net.minecraft.client.gui.widget.ThreePartsLayoutWidget;
import net.minecraft.client.gui.widget.DirectionalLayoutWidget;
import net.minecraft.client.gui.widget.ButtonWidget.PressAction;
import net.minecraft.client.gui.widget.GridWidget.Adder;
import net.minecraft.client.gui.widget.SliderWidget;
import org.jetbrains.annotations.NotNull;

public class ModSettingsScreen extends Screen {
   private static final ToggleableListScreen.Model BLOCKS_3D_MODEL = new ToggleableListScreen.Model(Registries.BLOCK.stream().filter(block -> {
      Set<Block> blacklistedBlocks = Set.of(Blocks.AIR, Blocks.WATER, Blocks.LAVA);
      return !blacklistedBlocks.contains(block);
   }).sorted(Comparator.comparing(block -> block.getName().getString())).map(block -> (ToggleableListScreen.ModelEntry)new ModSettingsScreen.BlockModel3DEntry(block)).toList());
   private static final ToggleableListScreen.Model BLOCKS_TRACED_MODEL;
   private final Screen parent;
   private SchematicExporter schematicExporter = null;
   private final ThreePartsLayoutWidget layout = new ThreePartsLayoutWidget(this, 61, 33);

   protected ModSettingsScreen(Screen parent) {
      super(Text.of("Photonic Client Settings"));
      this.parent = parent;
   }

   protected void init() {
      super.init();
      List<ModSettingsScreen.PButton> buttons = new ArrayList<>();
      buttons.add(
         new ModSettingsScreen.PButton(
            "Generate schematics.zip",
            w -> this.exportSchematics(),
            "Exports all blockstates to the root\nMinecraft folder (schematics.zip). Only works in-game!",
            () -> MinecraftClient.getInstance().world != null
         )
      );
      PhotonicsStorage.Parameter<Boolean> doMultithreading = PhotonicsStorage.DO_MULTITHREADING;
      buttons.add(new ModSettingsScreen.PButton("MultiThreading: " + (doMultithreading.value ? "On" : "Off"), w -> {
         doMultithreading.value = !doMultithreading.value;
         doMultithreading.modified();
         w.setMessage(Text.of("MultiThreading: " + (doMultithreading.value ? "On" : "Off")));
      }, "Turns MultiThreading on or off; MultiThreading is considerably faster, but can cause bugs.", () -> true));
      PhotonicsStorage.Parameter<Boolean> pixelatedProjection = PhotonicsStorage.PIXELATED_PROJECTION;
      PhotonicsStorage.Parameter<Float> castLightPixelSize = PhotonicsStorage.CAST_LIGHT_PIXEL_SIZE;
      ModSettingsScreen.CastLightPixelSizeSlider castLightPixelSizeSlider = new ModSettingsScreen.CastLightPixelSizeSlider(castLightPixelSize);
      castLightPixelSizeSlider.active = pixelatedProjection.value;
      buttons.add(new ModSettingsScreen.PButton("Pixelated Projection: " + (pixelatedProjection.value ? "On" : "Off"), w -> {
         pixelatedProjection.value = !pixelatedProjection.value;
         pixelatedProjection.modified();
         castLightPixelSizeSlider.active = pixelatedProjection.value;
         w.setMessage(Text.of("Pixelated Projection: " + (pixelatedProjection.value ? "On" : "Off")));
      }, "Turns pixelated projected RT cast light on or off.", () -> true));
      ModSettingsScreen.OilifySizeSlider oilifySizeSlider = new ModSettingsScreen.OilifySizeSlider(PhotonicsStorage.OILIFY_SIZE);
      oilifySizeSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifySharpnessSlider oilifySharpnessSlider = new ModSettingsScreen.OilifySharpnessSlider(PhotonicsStorage.OILIFY_SHARPNESS);
      oilifySharpnessSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyScaleSlider oilifyScaleSlider = new ModSettingsScreen.OilifyScaleSlider(PhotonicsStorage.OILIFY_SCALE);
      oilifyScaleSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyTuningSlider oilifyTuningSlider = new ModSettingsScreen.OilifyTuningSlider(PhotonicsStorage.OILIFY_TUNING);
      oilifyTuningSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyIterationsSlider oilifyIterationsSlider = new ModSettingsScreen.OilifyIterationsSlider(PhotonicsStorage.OILIFY_ITERATIONS);
      oilifyIterationsSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyDepthScalingSlider oilifyDepthScalingSlider = new ModSettingsScreen.OilifyDepthScalingSlider(PhotonicsStorage.OILIFY_DEPTH_SCALING);
      oilifyDepthScalingSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      ModSettingsScreen.OilifyStrokeStrengthSlider oilifyStrokeStrengthSlider = new ModSettingsScreen.OilifyStrokeStrengthSlider(PhotonicsStorage.OILIFY_STROKE_STRENGTH);
      oilifyStrokeStrengthSlider.active = PhotonicsStorage.OILIFY_ENABLED.value;
      PhotonicsStorage.Parameter<Boolean> oilify = PhotonicsStorage.OILIFY_ENABLED;
      buttons.add(new ModSettingsScreen.PButton("Oilify: " + (oilify.value ? "On" : "Off"), w -> {
         oilify.value = !oilify.value;
         oilify.modified();
         oilifySizeSlider.active = oilify.value;
         oilifySharpnessSlider.active = oilify.value;
         oilifyScaleSlider.active = oilify.value;
         oilifyTuningSlider.active = oilify.value;
         oilifyIterationsSlider.active = oilify.value;
         oilifyDepthScalingSlider.active = oilify.value;
         oilifyStrokeStrengthSlider.active = oilify.value;
         w.setMessage(Text.of("Oilify: " + (oilify.value ? "On" : "Off")));
      }, "Applies an oil painting effect to the world using\nan anisotropic Kuwahara filter.", () -> true));
      ToggleableListScreen volumetricRenderedBlocks = new ToggleableListScreen(this, "3D Blocks", BLOCKS_3D_MODEL);
      buttons.add(
         new ModSettingsScreen.PButton(
            "3D Blocks",
            w -> this.client.setScreen(volumetricRenderedBlocks),
            "Configures, whether a specific block should be rendered as a 3D block",
            () -> true
         )
      );
      ToggleableListScreen tracedBlocks = new ToggleableListScreen(this, "Raytraced Block Lights", BLOCKS_TRACED_MODEL);
      buttons.add(
         new ModSettingsScreen.PButton(
            "Raytraced Lights",
            w -> this.client.setScreen(tracedBlocks),
            "Configures, whether a specific block should emit ray-traced light",
            () -> true
         )
      );
      DirectionalLayoutWidget linearLayout = (DirectionalLayoutWidget)this.layout.addHeader(DirectionalLayoutWidget.vertical().spacing(8));
      linearLayout.add(new TextWidget(Text.of("Photonics Mod settings"), this.textRenderer), Positioner::alignHorizontalCenter);
      GridWidget gridLayout = new GridWidget();
      gridLayout.getMainPositioner().marginX(4).marginBottom(4).alignHorizontalCenter();
      Adder rowHelper = gridLayout.createAdder(2);
      int midX = this.width / 2;
      int i = 0;

      for (ModSettingsScreen.PButton button : buttons) {
         int x = i % 2 * 220 + midX - 210;
         int y = (i / 2 + 1) * 30;
         button.widget = ButtonWidget.builder(Text.of(button.text), button.pressAction)
            .position(x, y)
            .size(200, 20)
            .tooltip(Tooltip.of(Text.of(button.toolTip)))
            .build();
         button.widget.active = button.active.getAsBoolean();
         rowHelper.add(button.widget);
         i++;
      }

      rowHelper.add(castLightPixelSizeSlider, 2);
      rowHelper.add(oilifySizeSlider, 2);
      rowHelper.add(oilifySharpnessSlider, 2);
      rowHelper.add(oilifyScaleSlider, 2);
      rowHelper.add(oilifyTuningSlider, 2);
      rowHelper.add(oilifyIterationsSlider, 2);
      rowHelper.add(oilifyDepthScalingSlider, 2);
      rowHelper.add(oilifyStrokeStrengthSlider, 2);

      this.layout.addBody(gridLayout);
      this.layout.addFooter(ButtonWidget.builder(ScreenTexts.DONE, buttonx -> this.close()).width(200).build());
      this.layout.forEachChild(x$0 -> {
         ClickableWidget var10000 = (ClickableWidget)this.addDrawableChild(x$0);
      });
      this.layout.refreshPositions();
   }

   public void render(@NotNull DrawContext drawContext, int mouseX, int mouseY, float delta) {
      super.renderBackground(drawContext, mouseX, mouseY, delta);
      super.render(drawContext, mouseX, mouseY, delta);
   }

   public void exportSchematics() {
      if (this.schematicExporter == null) {
         try {
            this.schematicExporter = new SchematicExporter(new File("."));
            MinecraftClient.getInstance().setOverlay(buildLoadingOverlay(() -> {
               if (this.schematicExporter == null) {
                  return 1.0F;
               } else {
                  for (int i = 0; i < 100; i++) {
                     if (!this.schematicExporter.exportOne()) {
                        this.schematicExporter = null;
                        return 1.0F;
                     }
                  }

                  return this.schematicExporter.getProgress();
               }
            }));
         } catch (FileNotFoundException var2) {
            var2.printStackTrace();
         }
      }
   }

   public void close() {
      this.client.setScreen(this.parent);
   }

   private static SplashOverlay buildLoadingOverlay(Supplier<Float> progressSupplier) {
      return new SplashOverlay(MinecraftClient.getInstance(), new ResourceReload() {
         public CompletableFuture<Unit> whenComplete() {
            return null;
         }

         public float getProgress() {
            return progressSupplier.get();
         }

         public boolean isComplete() {
            return this.getProgress() == 1.0F;
         }
      }, o -> {}, false);
   }

   static {
      Set<LightBlock> lightBlocks = PhotonicsStorage.TRACED_LIGHT_BLOCKS.value;
      BLOCKS_TRACED_MODEL = new ToggleableListScreen.Model(
         lightBlocks.stream()
            .sorted(Comparator.comparing(lightblock -> lightblock.block.getName().getString()))
            .map(lightBlock -> (ToggleableListScreen.ModelEntry)new ModSettingsScreen.TracedLightBlockEntry(lightBlock.block))
            .toList()
      );
   }

   public static class BlockModel3DEntry extends ToggleableListScreen.ModelEntry {
      private final Block block;

      public BlockModel3DEntry(Block block) {
         this.block = block;
      }

      @Override
      public String getDisplayValue() {
         return this.block.getName().getString();
      }

      @Override
      public boolean isEnabled() {
         return PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS.value.contains(this.block);
      }

      @Override
      public void setEnabled(boolean enabled) {
         PhotonicsStorage.Parameter<Set<Block>> lightBlocks = PhotonicsStorage.VOLUMETRIC_RENDERED_BLOCKS;
         if (enabled) {
            lightBlocks.value.add(this.block);
         } else {
            lightBlocks.value.remove(this.block);
         }

         lightBlocks.modified();
      }
   }

   private static class PButton {
      public ButtonWidget widget;
      public final String text;
      public final PressAction pressAction;
      public final String toolTip;
      public final BooleanSupplier active;

      public PButton(String text, PressAction pressAction, String toolTip, BooleanSupplier active) {
         this.text = text;
         this.pressAction = pressAction;
         this.toolTip = toolTip;
         this.active = active;
      }
   }

   private static class CastLightPixelSizeSlider extends SliderWidget {
      private static final int MIN_PIXEL_SIZE = 1;
      private static final int MAX_PIXEL_SIZE = 24;
      private final PhotonicsStorage.Parameter<Float> castLightPixelSize;

      CastLightPixelSizeSlider(PhotonicsStorage.Parameter<Float> castLightPixelSize) {
         super(0, 0, 200, 20, Text.of(""), normalize(castLightPixelSize.value));
         this.castLightPixelSize = castLightPixelSize;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Cast Light Pixel Size: " + this.getPixelSize()));
      }

      @Override
      protected void applyValue() {
         this.castLightPixelSize.value = this.getPixelSize();
         this.castLightPixelSize.modified();
         this.updateMessage();
      }

      private static double normalize(float pixelSize) {
         float clamped = Math.max(MIN_PIXEL_SIZE, Math.min(MAX_PIXEL_SIZE, pixelSize));
         return (clamped - MIN_PIXEL_SIZE) / (MAX_PIXEL_SIZE - MIN_PIXEL_SIZE);
      }

      private float getPixelSize() {
         float pixelSize = MIN_PIXEL_SIZE + (float)Math.round(this.value * (MAX_PIXEL_SIZE - MIN_PIXEL_SIZE));
         return Math.max(MIN_PIXEL_SIZE, Math.min(MAX_PIXEL_SIZE, pixelSize));
      }
   }

   private static class OilifySizeSlider extends SliderWidget {
      private static final float MIN = 3.0f;
      private static final float MAX = 15.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifySizeSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), normalize(param.value));
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("OILIFY_SIZE: " + (int) getValue()));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         return Math.max(MIN, Math.min(MAX, MIN + Math.round((float)(this.value * (MAX - MIN)))));
      }
   }

   private static class OilifySharpnessSlider extends SliderWidget {
      private static final float MIN = 0.0f;
      private static final float MAX = 1.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifySharpnessSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), param.value);
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Sharpness: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private float getValue() {
         return (float) Math.max(MIN, Math.min(MAX, this.value));
      }
   }

   private static class OilifyScaleSlider extends SliderWidget {
      private static final float MIN = 1.0f;
      private static final float MAX = 4.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyScaleSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), normalize(param.value));
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Scale: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.value * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyTuningSlider extends SliderWidget {
      private static final float MIN = 0.0f;
      private static final float MAX = 4.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyTuningSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), normalize(param.value));
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Anistropy Tuning: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.value * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyIterationsSlider extends SliderWidget {
      private static final float MIN = 1.0f;
      private static final float MAX = 8.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyIterationsSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), normalize(param.value));
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("OILIFY_ITERATIONS: " + (int)getValue()));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         return Math.max(MIN, Math.min(MAX, MIN + Math.round((float)(this.value * (MAX - MIN)))));
      }
   }

   private static class OilifyDepthScalingSlider extends SliderWidget {
      private static final float MIN = 0.0f;
      private static final float MAX = 2.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyDepthScalingSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), normalize(param.value));
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Depth Scaling: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private static double normalize(float val) {
         return (Math.max(MIN, Math.min(MAX, val)) - MIN) / (MAX - MIN);
      }

      private float getValue() {
         float raw = (float)(MIN + this.value * (MAX - MIN));
         return Math.max(MIN, Math.min(MAX, raw));
      }
   }

   private static class OilifyStrokeStrengthSlider extends SliderWidget {
      private static final float MIN = 0.0f;
      private static final float MAX = 1.0f;
      private final PhotonicsStorage.Parameter<Float> param;

      OilifyStrokeStrengthSlider(PhotonicsStorage.Parameter<Float> param) {
         super(0, 0, 200, 20, Text.of(""), param.value);
         this.param = param;
         this.updateMessage();
      }

      @Override
      protected void updateMessage() {
         this.setMessage(Text.of("Stroke Strength: " + String.format("%.2f", getValue())));
      }

      @Override
      protected void applyValue() {
         this.param.value = getValue();
         this.param.modified();
         this.updateMessage();
      }

      private float getValue() {
         return (float) Math.max(MIN, Math.min(MAX, this.value));
      }
   }

   public static class TracedLightBlockEntry extends ToggleableListScreen.ModelEntry {
      private final Block block;

      public TracedLightBlockEntry(Block block) {
         this.block = block;
      }

      @Override
      public String getDisplayValue() {
         return Registries.BLOCK.getId(this.block).getPath();
      }

      @Override
      public boolean isEnabled() {
         return PhotonicsStorage.TRACED_LIGHT_BLOCKS.value.stream().anyMatch(lightBlock -> lightBlock.block == this.block && lightBlock.lightType.isTraced());
      }

      @Override
      public void setEnabled(boolean traced) {
         PhotonicsStorage.Parameter<Set<LightBlock>> lightBlocks = PhotonicsStorage.TRACED_LIGHT_BLOCKS;
         LightBlock lightBlock = lightBlocks.value.stream().filter(lightBlock1 -> lightBlock1.block == this.block).findFirst().orElse(null);
         if (lightBlock != null) {
            lightBlock.lightType = new LightType(lightBlock.lightType.getColor(), lightBlock.lightType.getAttenuation(), traced);
            lightBlocks.modified();
         }
      }
   }
}
