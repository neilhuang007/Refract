package at.redi2go.photonic.client;

import at.redi2go.photonic.client.rendering.world.LightBlock;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.block.Block;

public final class PhotonicsStorage {
   private static final Map<String, String[]> CONFIG_VALUES = StorageIO.readConfig();
   public static final PhotonicsStorage.Parameter<Boolean> DO_MULTITHREADING = new PhotonicsStorage.Parameter<>(
      "do_multithreading", booleanString -> StorageIO.readBoolean(booleanString, false), StorageIO::writeBoolean
   );
   public static final PhotonicsStorage.Parameter<Boolean> PIXELATED_PROJECTION = new PhotonicsStorage.Parameter<>(
      "pixelated_projection", booleanString -> StorageIO.readBoolean(booleanString, true), StorageIO::writeBoolean
   );
   public static final PhotonicsStorage.Parameter<Boolean> OILIFY_ENABLED = new PhotonicsStorage.Parameter<>(
      "oilify_enabled", booleanString -> StorageIO.readBoolean(booleanString, false), StorageIO::writeBoolean
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_SIZE = new PhotonicsStorage.Parameter<>(
      "oilify_size", floatString -> StorageIO.readFloat(floatString, 7.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_SHARPNESS = new PhotonicsStorage.Parameter<>(
      "oilify_sharpness", floatString -> StorageIO.readFloat(floatString, 1.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_SCALE = new PhotonicsStorage.Parameter<>(
      "oilify_scale", floatString -> StorageIO.readFloat(floatString, 1.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_TUNING = new PhotonicsStorage.Parameter<>(
      "oilify_tuning", floatString -> StorageIO.readFloat(floatString, 2.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_ITERATIONS = new PhotonicsStorage.Parameter<>(
      "oilify_iterations", floatString -> StorageIO.readFloat(floatString, 1.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_DEPTH_SCALING = new PhotonicsStorage.Parameter<>(
      "oilify_depth_scaling", floatString -> StorageIO.readFloat(floatString, 0.5F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> OILIFY_STROKE_STRENGTH = new PhotonicsStorage.Parameter<>(
      "oilify_stroke_strength", floatString -> StorageIO.readFloat(floatString, 0.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Float> CAST_LIGHT_PIXEL_SIZE = new PhotonicsStorage.Parameter<>(
      "cast_light_pixel_size", floatString -> StorageIO.readFloat(floatString, 8.0F), StorageIO::writeFloat
   );
   public static final PhotonicsStorage.Parameter<Set<Block>> VOLUMETRIC_RENDERED_BLOCKS = new PhotonicsStorage.Parameter<>(
      "volumetric_blocks",
      blocksString -> new HashSet<>(StorageIO.readBlocks(blocksString, Raytracer.DEFAULT_VOLUMETRIC_RENDERED_BLOCKS)),
      StorageIO::writeBlocks
   );
   public static final PhotonicsStorage.Parameter<Set<LightBlock>> TRACED_LIGHT_BLOCKS = new PhotonicsStorage.Parameter<>(
      "traced_light_blocks",
      lightBlocksString -> new HashSet<>(StorageIO.readLightBlocks(lightBlocksString, Raytracer.DEFAULT_LIGHT_BLOCKS)),
      StorageIO::writeLightBlocks
   );

   public static class Parameter<T> {
      private final List<Consumer<T>> observers = new LinkedList<>();
      public final String configKey;
      public final Function<T, String[]> serializer;
      public T value;

      public Parameter(String configKey, Function<String[], T> deserializer, Function<T, String[]> serializer) {
         this.configKey = configKey;
         this.serializer = serializer;
         this.value = deserializer.apply(PhotonicsStorage.CONFIG_VALUES.get(configKey));
      }

      public void modified() {
         this.observers.forEach(observer -> observer.accept(this.value));
         PhotonicsStorage.CONFIG_VALUES.put(this.configKey, this.serializer.apply(this.value));
         StorageIO.writeConfig(PhotonicsStorage.CONFIG_VALUES);
      }

      public void addObserver(Consumer<T> observer) {
         this.observers.add(observer);
      }

      public void removeObserver(Consumer<T> observer) {
         this.observers.remove(observer);
      }
   }
}
