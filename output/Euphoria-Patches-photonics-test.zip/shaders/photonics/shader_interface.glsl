#define shadow2D texture
#define texture2D texture
#define texture2DLod textureLod
#define FRAGMENT_SHADER

#include "/lib/common.glsl"
#include "/lib/util/spaceConversion.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/antialiasing/jitter.glsl"
#include "/lib/shaderSettings/photonics.glsl"

uniform vec3 sunPosition;
uniform vec3 upPosition;

vec3 sunVec = normalize(sunPosition);
vec3 upVec = normalize(upPosition);
vec3 sunVecWorld = normalize(mat3(gbufferModelViewInverse) * sunVec);

float SdotU = dot(sunVec, upVec);
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;

#include "/lib/colors/lightAndAmbientColors.glsl"

float sunVisibilitySaturated = clamp((dot(sunVec, upVec) + 0.0625f) / 0.125f, 0.0f, 1.0f);
vec3 lightVecWorld = (sunVecWorld.y < 0.0f) ? -sunVecWorld : sunVecWorld;

vec3 load_world_position() {
    vec2 texCoord = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    float z0 = texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).r;
    #ifdef TAA
        vec3 screenPos = vec3(TAAJitter(texCoord, -0.5), z0);
    #else
        vec3 screenPos = vec3(texCoord, z0);
    #endif
    vec3 playerPos = ViewToPlayer(ScreenToView(screenPos));
    #ifdef PHOTONICS_PIXELATED_SHADOWS
        vec2 texelOffset = texelFetch(colortex11, texelCoord, 0).rg;
        playerPos = TexelSnap(playerPos, texelOffset);
    #endif

    return playerPos + cameraPosition;
}

void load_fragment_variables(out vec3 albedo, out vec3 world_pos, out vec3 world_normal, out vec3 world_normal_mapped) {
    albedo = texelFetch(colortex10, texelCoord, 0).xyz;
    world_normal = texelFetch(colortex4, texelCoord, 0).xyz;
    world_normal_mapped = world_normal;
    world_pos = load_world_position() - 0.01f * world_normal;
}

vec3 sun_direction = normalize(lightVecWorld);

vec3 indirect_light_color = 0.5f * mix(lightColor, vec3(GetLuminance(lightColor)), 0.8f) * clamp(0.6f + sunVisibility2, 0.0f, 1.0f);

vec2 get_taa_jitter() { return vec2(0.0f); }

vec3 get_sky_color(ivec2 gBufferLoc, vec3 worldPos, vec3 newNormal) {
    vec2 texCoord = vec2(gBufferLoc) / vec2(viewWidth, viewHeight);
    vec3 screenPos = vec3(texCoord, texture(depthtex0, texCoord).r);
    vec3 viewDir = normalize(ScreenToView(screenPos));
    vec3 viewNormal = normalize(mat3(transpose(gbufferModelViewInverse)) * newNormal);
    vec3 reflectedDir = reflect(viewDir, viewNormal);
    float horizonFactor = clamp(dot(reflectedDir, upVec) * 0.5f + 0.5f, 0.0f, 1.0f);
    float sunScatter = pow(max(dot(reflectedDir, normalize(lightVecWorld)), 0.0f), 64.0f);
    vec3 skyTop = mix(vec3(0.02f, 0.03f, 0.05f), vec3(0.32f, 0.55f, 0.95f), sunVisibilitySaturated);
    vec3 skyHorizon = mix(vec3(0.01f, 0.02f, 0.04f), vec3(0.58f, 0.65f, 0.78f), sunVisibilitySaturated);
    float dither = Bayer8(gl_FragCoord.xy);
    return mix(skyHorizon, skyTop, pow(horizonFactor, 1.25f)) + vec3(1.1f, 0.95f, 0.8f) * sunScatter + (dither - 0.5f) / 256.0f;
}

bool is_in_world() { return texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).x <= 0.99999f; }


#define PH_USE_CUSTOM_ALPHA
#define PH_ALPHA_FUNC(color) apply_tint_impl(color)

vec3 apply_tint_impl(vec4 color) {
    #if PHOTONICS_LIGHTING_MODE == 0
        float tintStrength = 1.66;
        float tintSaturation = 1.35;
    #elif PHOTONICS_LIGHTING_MODE == 1
        float tintStrength = 1.0;
        float tintSaturation = 1.2;
    #endif
    return clamp01(saturateColors(mix(
        color.rgb,
        vec3(step(color.a, 0.5)),
        abs((color.a * 2f) - 1f)
    ), tintSaturation) * tintStrength);
}
