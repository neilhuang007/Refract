/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.item;

import java.util.Collection;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.fabricmc.fabric.api.item.v1.EnchantingContext;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2168;
import net.minecraft.class_3048;
import net.minecraft.class_6880;

@Mixin(class_3048.class)
abstract class EnchantCommandMixin {
	@Redirect(
			method = "execute",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/enchantment/Enchantment;isAcceptableItem(Lnet/minecraft/item/ItemStack;)Z")
	)
	private static boolean callAllowEnchantingEvent(class_1887 instance, class_1799 stack, class_2168 source, Collection<? extends class_1297> targets, class_6880<class_1887> enchantment) {
		return stack.canBeEnchantedWith(enchantment, EnchantingContext.ACCEPTABLE);
	}
}
