/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag.convention.v2;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * A Helper class for checking whether a {@link class_6862} contains some entry.
 * This can be useful for {@link class_6862}s whose type has no easy way of querying if they are in a tag, such as {@link net.minecraft.class_1887}s.
 *
 * <p>For dynamic registry entries, use {@link #isIn(class_5455, class_6862, Object)} with a non-null dynamic registry manager.
 * For non-dynamic registry entries, the simpler {@link #isIn(class_6862, Object)} can be used.
 */
public final class TagUtil {
	public static final String C_TAG_NAMESPACE = "c";
	public static final String FABRIC_TAG_NAMESPACE = "fabric";

	private TagUtil() {
	}

	/**
	 * See {@link TagUtil#isIn(class_5455, class_6862, Object)} to check tags that refer to entries in dynamic
	 * registries, such as {@link net.minecraft.class_1959}s.
	 * @return if the entry is in the provided tag.
	 */
	public static <T> boolean isIn(class_6862<T> tagKey, T entry) {
		return isIn(null, tagKey, entry);
	}

	/**
	 * @param registryManager the registry manager instance of the client or server. If the tag refers to entries
	 *                        within a dynamic registry, such as {@link net.minecraft.class_1959}s,
	 *                        this must be passed to correctly evaluate the tag. Otherwise, the registry is found by
	 *                        looking in {@link class_7923#field_41167}.
	 * @return if the entry is in the provided tag.
	 */
	@SuppressWarnings("unchecked")
	public static <T> boolean isIn(@Nullable class_5455 registryManager, class_6862<T> tagKey, T entry) {
		Optional<? extends class_2378<?>> maybeRegistry;
		Objects.requireNonNull(tagKey);
		Objects.requireNonNull(entry);

		if (registryManager != null) {
			maybeRegistry = registryManager.method_33310(tagKey.comp_326());
		} else {
			maybeRegistry = class_7923.field_41167.method_17966(tagKey.comp_326().method_29177());
		}

		if (maybeRegistry.isPresent()) {
			if (tagKey.method_41007(maybeRegistry.get().method_30517())) {
				class_2378<T> registry = (class_2378<T>) maybeRegistry.get();

				Optional<class_5321<T>> maybeKey = registry.method_29113(entry);

				// Check synced tag
				if (maybeKey.isPresent()) {
					return registry.method_40290(maybeKey.get()).method_40220(tagKey);
				}
			}
		}

		return false;
	}
}
