/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.registry.sync.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.impl.registry.sync.trackers.IdListTracker;
import net.minecraft.class_2361;
import net.minecraft.class_322;
import net.minecraft.class_324;
import net.minecraft.class_7923;

@Mixin(class_324.class)
public class BlockColorsMixin {
	@Final
	@Shadow
	private class_2361<class_322> providers;

	@Inject(method = "<init>", at = @At("RETURN"))
	private void create(CallbackInfo info) {
		IdListTracker.register(class_7923.field_41175, "BlockColors.providers", providers);
	}
}
