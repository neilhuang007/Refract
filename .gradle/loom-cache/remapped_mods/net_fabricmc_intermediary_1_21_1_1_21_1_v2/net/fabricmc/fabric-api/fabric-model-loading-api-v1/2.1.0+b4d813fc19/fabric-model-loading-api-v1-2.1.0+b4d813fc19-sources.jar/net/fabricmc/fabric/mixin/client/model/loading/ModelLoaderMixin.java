/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.client.model.loading;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.client.model.loading.BakerImplHooks;
import net.fabricmc.fabric.impl.client.model.loading.BlockStatesLoaderHooks;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoaderHooks;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoadingConstants;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoadingEventDispatcher;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoadingPluginManager;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_324;
import net.minecraft.class_3665;
import net.minecraft.class_3695;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_9824;

@Mixin(class_1088.class)
abstract class ModelLoaderMixin implements ModelLoaderHooks {
	@Final
	@Shadow
	private Set<class_2960> modelsToLoad;
	@Final
	@Shadow
	private Map<class_2960, class_1100> unbakedModels;
	@Shadow
	@Final
	private Map<class_1091, class_1100> modelsToBake;
	@Shadow
	@Final
	private class_1100 missingModel;

	@Unique
	private ModelLoadingEventDispatcher fabric_eventDispatcher;
	@Unique
	private final ObjectLinkedOpenHashSet<class_2960> modelLoadingStack = new ObjectLinkedOpenHashSet<>();

	@Shadow
	abstract class_1100 getOrLoadModel(class_2960 id);

	@Shadow
	abstract void add(class_1091 id, class_1100 unbakedModel);

	@Shadow
	abstract class_793 loadModelFromJson(class_2960 id);

	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/model/BlockStatesLoader;load()V"))
	private void afterMissingModelInit(class_324 blockColors, class_3695 profiler, Map<class_2960, class_793> jsonUnbakedModels, Map<class_2960, List<class_9824.class_7777>> blockStates, CallbackInfo info, @Local class_9824 blockStatesLoader) {
		// Sanity check
		if (missingModel == null || !modelsToBake.containsKey(class_1088.field_52276)) {
			throw new AssertionError("Missing model not initialized. This is likely a Fabric API porting bug.");
		}

		// Add the missing model to the cache since vanilla doesn't. Mods may load/bake the missing model directly.
		unbakedModels.put(class_1088.field_5374, missingModel);
		profiler.method_15405("fabric_plugins_init");

		fabric_eventDispatcher = new ModelLoadingEventDispatcher((class_1088) (Object) this, ModelLoadingPluginManager.CURRENT_PLUGINS.get());
		fabric_eventDispatcher.addExtraModels(this::addExtraModel);
		((BlockStatesLoaderHooks) blockStatesLoader).fabric_setLoadingOverride(fabric_eventDispatcher::loadBlockStateModels);
	}

	@Unique
	private void addExtraModel(class_2960 id) {
		class_1091 modelId = ModelLoadingConstants.toResourceModelId(id);
		class_1100 unbakedModel = getOrLoadModel(id);
		add(modelId, unbakedModel);
	}

	@Inject(method = "getOrLoadModel", at = @At("HEAD"), cancellable = true)
	private void allowRecursiveLoading(class_2960 id, CallbackInfoReturnable<class_1100> cir) {
		// If the stack is empty, this is the top-level call, so proceed as normal.
		if (!modelLoadingStack.isEmpty()) {
			if (unbakedModels.containsKey(id)) {
				cir.setReturnValue(unbakedModels.get(id));
			} else if (modelLoadingStack.contains(id)) {
				throw new IllegalStateException("Circular reference while loading model '" + id + "' (" + modelLoadingStack.stream().map(i -> i + "->").collect(Collectors.joining()) + id + ")");
			} else {
				class_1100 model = loadModel(id);
				unbakedModels.put(id, model);
				// These will be loaded at the top-level call.
				modelsToLoad.addAll(model.method_4755());
				cir.setReturnValue(model);
			}
		}
	}

	// This is the call that needs to be redirected to support ModelResolvers, but it returns a JsonUnbakedModel.
	// Redirect it to always return null and handle the logic in a ModifyVariable right after the call.
	@Redirect(method = "getOrLoadModel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/model/ModelLoader;loadModelFromJson(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/render/model/json/JsonUnbakedModel;"))
	private class_793 cancelLoadModelFromJson(class_1088 self, class_2960 id) {
		return null;
	}

	@ModifyVariable(method = "getOrLoadModel", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/client/render/model/ModelLoader;loadModelFromJson(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/render/model/json/JsonUnbakedModel;"))
	private class_1100 doLoadModel(class_1100 model, @Local(ordinal = 1) class_2960 id) {
		return loadModel(id);
	}

	@Unique
	private class_1100 loadModel(class_2960 id) {
		modelLoadingStack.add(id);

		try {
			class_1100 model = fabric_eventDispatcher.resolveModel(id);

			if (model == null) {
				model = loadModelFromJson(id);
			}

			return fabric_eventDispatcher.modifyModelOnLoad(model, id, null);
		} finally {
			modelLoadingStack.removeLast();
		}
	}

	@ModifyVariable(method = "add", at = @At("HEAD"), argsOnly = true)
	private class_1100 onAdd(class_1100 model, class_1091 id) {
		if (ModelLoadingConstants.isResourceModelId(id)) {
			return model;
		}

		return fabric_eventDispatcher.modifyModelOnLoad(model, null, id);
	}

	@WrapOperation(method = "method_61072(Lnet/minecraft/client/render/model/ModelLoader$SpriteGetter;Lnet/minecraft/client/util/ModelIdentifier;Lnet/minecraft/client/render/model/UnbakedModel;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/model/ModelLoader$BakerImpl;bake(Lnet/minecraft/client/render/model/UnbakedModel;Lnet/minecraft/client/render/model/ModelBakeSettings;)Lnet/minecraft/client/render/model/BakedModel;"))
	private class_1087 wrapSingleOuterBake(@Coerce class_7775 baker, class_1100 unbakedModel, class_3665 settings, Operation<class_1087> operation, class_1088.class_9826 spriteGetter, class_1091 id) {
		if (ModelLoadingConstants.isResourceModelId(id) || id.equals(class_1088.field_52276)) {
			// Call the baker instead of the operation to ensure the baked model is cached and doesn't end up going
			// through events twice.
			// This ignores the UnbakedModel in modelsToBake but it should be the same as the one in unbakedModels.
			return baker.method_45873(id.comp_2875(), settings);
		}

		Function<class_4730, class_1058> textureGetter = ((BakerImplHooks) baker).fabric_getTextureGetter();
		unbakedModel = fabric_eventDispatcher.modifyModelBeforeBake(unbakedModel, null, id, textureGetter, settings, baker);
		class_1087 model = operation.call(baker, unbakedModel, settings);
		return fabric_eventDispatcher.modifyModelAfterBake(model, null, id, unbakedModel, textureGetter, settings, baker);
	}

	@Override
	public ModelLoadingEventDispatcher fabric_getDispatcher() {
		return fabric_eventDispatcher;
	}

	@Override
	public class_1100 fabric_getMissingModel() {
		return missingModel;
	}

	@Override
	public class_1100 fabric_getOrLoadModel(class_2960 id) {
		return getOrLoadModel(id);
	}

	@Override
	public void fabric_add(class_1091 id, class_1100 model) {
		add(id, model);
	}
}
